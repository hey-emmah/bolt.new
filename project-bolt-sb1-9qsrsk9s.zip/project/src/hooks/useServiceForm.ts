import { useState } from 'react';
import { ServiceParameters } from '../types/service';

const initialFormData: ServiceParameters = {
  name: '',
  description: '',
  platform: {
    name: '',
    type: '',
    environment: ''
  },
  dependencies: [],
  observability: {
    logs: 'datadog'
  },
  on_call: []
};

export function useServiceForm() {
  const [formData, setFormData] = useState<ServiceParameters>(initialFormData);

  const updateFormData = (updates: Partial<ServiceParameters>) => {
    setFormData(prev => ({
      ...prev,
      ...updates
    }));
  };

  const resetForm = () => {
    setFormData(initialFormData);
  };

  return {
    formData,
    updateFormData,
    resetForm
  };
}