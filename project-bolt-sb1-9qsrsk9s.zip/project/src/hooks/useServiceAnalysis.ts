import { useState } from 'react';
import { AnalyzeResponse, ServiceParameters } from '../types/service';
import { mockApi } from '../lib/mockApi';
import { useCommandHistory } from './useCommandHistory';

export function useServiceAnalysis() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [serviceResponse, setServiceResponse] = useState<AnalyzeResponse | null>(null);
  
  const { commands, addCommand } = useCommandHistory();

  const analyzeService = async (params: ServiceParameters) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await mockApi.analyzeParameters();
      addCommand('service-configuration', 'Service configuration saved');
      
      setServiceResponse(response);
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to analyze service';
      setError(message);
      addCommand('service-configuration-failed', message, 'error');
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    error,
    serviceResponse,
    commands,
    analyzeService,
    addCommand
  };
}