import { useState, useEffect } from 'react';
import { ProvisioningStatusType } from '../types/observability';
import { observabilityApi } from '../lib/observabilityApi';

export function useObservabilityProvisioning() {
  const [isProvisioning, setIsProvisioning] = useState(false);
  const [status, setStatus] = useState<ProvisioningStatusType | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [provisioningId, setProvisioningId] = useState<string | null>(null);

  useEffect(() => {
    let intervalId: NodeJS.Timeout;

    if (isProvisioning && provisioningId) {
      intervalId = setInterval(async () => {
        try {
          const response = await observabilityApi.checkStatus(provisioningId);
          
          if (response.status === 'success') {
            setStatus('success');
            setIsProvisioning(false);
            clearInterval(intervalId);
          } else if (response.status === 'failed') {
            setError('Provisioning failed. Please try again.');
            setIsProvisioning(false);
            clearInterval(intervalId);
          }
        } catch (err) {
          setError('Failed to check provisioning status');
          setIsProvisioning(false);
          clearInterval(intervalId);
        }
      }, 5000); // Check every 5 seconds
    }

    return () => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [isProvisioning, provisioningId]);

  const startProvisioning = async () => {
    try {
      setIsProvisioning(true);
      setError(null);
      
      const response = await observabilityApi.startProvisioning();
      setProvisioningId(response.provisioningId);
    } catch (err) {
      setError('Failed to start provisioning');
      setIsProvisioning(false);
    }
  };

  return {
    status,
    isProvisioning,
    error,
    startProvisioning
  };
}