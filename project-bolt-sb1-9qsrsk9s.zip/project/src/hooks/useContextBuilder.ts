import { useState } from 'react';
import { mockApi } from '../lib/mockApi';
import { AnalyzeResponse, BuildContextResponse, ServiceParameters } from '../types/service';
import { useCommandHistory } from './useCommandHistory';

interface ContextBuilderState {
  loading: boolean;
  error: string | null;
  contextUrl: string | null;
}

export function useContextBuilder() {
  const [state, setState] = useState<ContextBuilderState>({
    loading: false,
    error: null,
    contextUrl: null
  });

  const { addCommand } = useCommandHistory();

  const buildContext = async (
    serviceResponse: AnalyzeResponse,
    formData: ServiceParameters
  ) => {
    setState({ loading: true, error: null, contextUrl: null });

    try {
      addCommand('build-context', 'Building context document...');
      const response = await mockApi.buildContext({
        'logs.service_name': formData.observability.logs.service_name,
        context_id: serviceResponse.context_id,
        vm_id: serviceResponse.vm_id
      });

      addCommand('context-build', 'Context document generated successfully');
      setState({
        loading: false,
        error: null,
        contextUrl: response.cloudinary_url
      });

      return response;
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to build context';
      setState({ loading: false, error: message, contextUrl: null });
      addCommand('context-build-failed', message, 'error');
      throw error;
    }
  };

  return {
    ...state,
    buildContext
  };
}