import { useState } from 'react';
import { analyzeParameters } from '../lib/api';
import { ServiceParameters, AnalyzeResponse } from '../types/service';

interface AnalyzeState {
  loading: boolean;
  error: string | null;
  response: AnalyzeResponse | null;
}

export function useAnalyzeContext() {
  const [state, setState] = useState<AnalyzeState>({
    loading: false,
    error: null,
    response: null
  });

  const analyze = async (parameters: ServiceParameters) => {
    setState({ loading: true, error: null, response: null });
    
    try {
      const response = await analyzeParameters(parameters);
      setState({ loading: false, error: null, response });
      return response;
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to analyze parameters';
      setState({ loading: false, error: message, response: null });
      throw error;
    }
  };

  return { ...state, analyze };
}