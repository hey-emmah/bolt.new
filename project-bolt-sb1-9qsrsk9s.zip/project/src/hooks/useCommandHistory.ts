import { useState } from 'react';

export interface Command {
  command: string;
  output?: string;
  status: 'success' | 'error';
}

export function useCommandHistory() {
  const [commands, setCommands] = useState<Command[]>([]);

  const addCommand = (command: string, output?: string, status: Command['status'] = 'success') => {
    setCommands(prev => [...prev, { command, output, status }]);
  };

  return {
    commands,
    addCommand
  };
}