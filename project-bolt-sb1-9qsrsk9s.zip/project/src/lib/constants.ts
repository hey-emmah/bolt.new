export const APP_VERSION = 'v0.1.0-alpha';
export const APP_NAME = 'Clete';

export const STEPS = [
  { id: 'basic', label: 'Basic Info', command: 'clete init' },
  { id: 'platform', label: 'Platform', command: 'clete config platform' },
  { id: 'dependencies', label: 'Dependencies', command: 'clete add deps' },
  { id: 'contacts', label: 'Contacts', command: 'clete set contacts' }
] as const;

export const PLATFORM_TYPES = [
  { value: 'Compute', label: 'Compute' },
  { value: 'Storage', label: 'Storage' },
  { value: 'Network', label: 'Network' }
] as const;

export const ENVIRONMENTS = [
  { value: 'development', label: 'Development' },
  { value: 'staging', label: 'Staging' },
  { value: 'production', label: 'Production' }
] as const;

export const DEPENDENCIES = [
  'PostgreSQL (RDS)',
  'Redis (Elasticache)',
  'MongoDB',
  'ElasticSearch'
] as const;

export const TERMINAL_COLORS = {
  bg: '#1E1E1E',
  header: '#2D2D2D',
  text: '#50FA7B',
  dimText: '#6B7280',
  border: '#374151'
} as const;