import { AnalyzeResponse, BuildContextResponse } from '../types/service';

// Mock API responses for development
export const mockApi = {
  analyzeParameters: async () => {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    return {
      required_parameters: ['logs.service_name'],
      context_type: 'new',
      context_id: '67',
      vm_id: '12345',
      analysis: {
        service_name: 'valid',
        platform_config: 'valid',
        dependencies: 'valid',
        contacts: 'valid'
      }
    } as AnalyzeResponse;
  },
  
  buildContext: async (params: Record<string, string>) => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    return {
      cloudinary_url: 'https://res.cloudinary.com/demo/image/upload/context-doc.pdf',
      context_id: params.context_id
    } as BuildContextResponse;
  }
};