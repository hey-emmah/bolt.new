import { ServiceParameters, AnalyzeResponse } from '../types/service';

const API_BASE_URL = 'http://localhost:5000';

class APIError extends Error {
  constructor(message: string, public status?: number) {
    super(message);
    this.name = 'APIError';
  }
}

async function fetchAPI<T>(endpoint: string, options: RequestInit): Promise<T> {
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
    });

    if (!response.ok) {
      throw new APIError(`API request failed: ${response.statusText}`, response.status);
    }

    return response.json();
  } catch (error) {
    if (error instanceof APIError) throw error;
    throw new APIError('Failed to connect to API');
  }
}

export async function analyzeParameters(params: ServiceParameters): Promise<AnalyzeResponse> {
  return fetchAPI<AnalyzeResponse>('/setup/analyze/parameters', {
    method: 'POST',
    body: JSON.stringify(params),
  });
}

export async function buildContext(params: Record<string, string>): Promise<{ cloudinary_url: string }> {
  return fetchAPI<{ cloudinary_url: string }>('/setup/context/build', {
    method: 'POST',
    body: JSON.stringify(params),
  });
}