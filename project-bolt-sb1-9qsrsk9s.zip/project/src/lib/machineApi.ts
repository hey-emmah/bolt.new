import { ProvisioningResponse, StatusResponse } from '../types/machine';

export const machineApi = {
  startProvisioning: async (): Promise<ProvisioningResponse> => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    return {
      provisioningId: 'machine_' + Math.random().toString(36).substr(2, 9)
    };
  },

  checkStatus: async (provisioningId: string): Promise<StatusResponse> => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Simulate success after a few checks
    const shouldSucceed = Math.random() > 0.7;
    
    return {
      status: shouldSucceed ? 'success' : 'in_progress',
      provisioningId
    };
  }
};