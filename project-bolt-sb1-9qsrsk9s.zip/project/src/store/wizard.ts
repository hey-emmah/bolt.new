import { create } from 'zustand';

export type WizardStep = 'business' | 'resources' | 'parameters' | 'security' | 'connection';

interface WizardState {
  currentStep: WizardStep;
  setStep: (step: WizardStep) => void;
  data: {
    business: {
      name: string;
    };
    resources: {
      memory: number;
      vcpus: number;
      diskSize: number;
    };
    parameters: {
      serviceName: string;
      platformType: string;
      environment: string;
    };
    security: {
      username: string;
      password: string;
    };
    connection: {
      connectionName: string;
      password: string;
    };
  };
  updateData: (section: keyof WizardState['data'], data: any) => void;
}

export const useWizardStore = create<WizardState>((set) => ({
  currentStep: 'business',
  setStep: (step) => set({ currentStep: step }),
  data: {
    business: { name: '' },
    resources: { memory: 1024, vcpus: 2, diskSize: 20 },
    parameters: { serviceName: '', platformType: '', environment: '' },
    security: { username: '', password: '' },
    connection: { connectionName: '', password: '' }
  },
  updateData: (section, data) => 
    set((state) => ({
      data: {
        ...state.data,
        [section]: { ...state.data[section], ...data }
      }
    }))
}));