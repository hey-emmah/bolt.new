import React, { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { APP_NAME, TERMINAL_COLORS } from '../../lib/constants';

interface TerminalWindowProps {
  children: ReactNode;
}

export function TerminalWindow({ children }: TerminalWindowProps) {
  return (
    <div className="bg-[#1E1E1E] rounded-lg border border-gray-800 overflow-hidden">
      <div className="bg-[#2D2D2D] px-4 py-2 flex items-center justify-between border-b border-gray-700">
        <div className="flex items-center gap-2">
          <div className="flex gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500" />
            <div className="w-3 h-3 rounded-full bg-yellow-500" />
            <div className="w-3 h-3 rounded-full bg-green-500" />
          </div>
          <span className="text-sm text-gray-400 ml-2">{APP_NAME.toLowerCase()}</span>
        </div>
        <div className="text-sm text-gray-500">~/context</div>
      </div>
      <motion.div 
        className="p-4 font-mono"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.3 }}
      >
        {children}
      </motion.div>
    </div>
  );
}