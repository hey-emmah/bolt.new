import React from 'react';
import { motion } from 'framer-motion';

interface CommandPromptProps {
  command: string;
  output?: string;
}

export function CommandPrompt({ command, output }: CommandPromptProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-2"
    >
      <div className="flex items-center gap-2">
        <span className="text-gray-500">$</span>
        <span className="text-green-400">{command}</span>
      </div>
      {output && (
        <div className="pl-6 text-gray-400 border-l border-gray-700">
          {output}
        </div>
      )}
    </motion.div>
  );
}