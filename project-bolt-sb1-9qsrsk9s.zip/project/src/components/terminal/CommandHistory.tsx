import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface Command {
  command: string;
  output?: string;
  status: 'success' | 'error';
}

interface CommandHistoryProps {
  commands: Command[];
}

export function CommandHistory({ commands }: CommandHistoryProps) {
  return (
    <div className="space-y-4">
      <AnimatePresence mode="popLayout">
        {commands.map((cmd, index) => (
          <motion.div
            key={`${cmd.command}-${index}`}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            className="space-y-1"
          >
            <div className="flex items-center gap-2">
              <span className="text-gray-500">$</span>
              <span className="text-green-400">{cmd.command}</span>
            </div>
            {cmd.output && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.1 }}
                className="pl-6 text-gray-400 border-l border-gray-700"
              >
                {cmd.output}
              </motion.div>
            )}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}