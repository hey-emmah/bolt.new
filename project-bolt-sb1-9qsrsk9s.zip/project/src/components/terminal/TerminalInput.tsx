import React, { InputHTMLAttributes } from 'react';
import { motion } from 'framer-motion';

interface TerminalInputProps extends InputHTMLAttributes<HTMLInputElement> {
  label: string;
}

export function TerminalInput({ label, ...props }: TerminalInputProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 5 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-2"
    >
      <label className="block text-sm text-gray-400">{label}</label>
      <input
        {...props}
        className="w-full px-4 py-2 bg-[#2D2D2D] border border-gray-700 rounded text-green-400 placeholder-gray-600 focus:outline-none focus:border-green-500 focus:ring-1 focus:ring-green-500"
      />
    </motion.div>
  );
}