import React, { useState } from 'react';
import { ServiceForm } from './service/ServiceForm';
import { ServiceParameters, AnalyzeResponse } from '../types/service';
import { analyzeParameters, buildContext } from '../lib/api';
import { ErrorMessage } from './ui/ErrorMessage';
import { SuccessMessage } from './ui/SuccessMessage';
import { CommandPrompt } from './terminal/CommandPrompt';

interface ServiceAnalyzerProps {
  onAnalyzed: (response: AnalyzeResponse) => void;
}

export function ServiceAnalyzer({ onAnalyzed }: ServiceAnalyzerProps) {
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [cloudinaryUrl, setCloudinaryUrl] = useState<string | null>(null);
  const [commandHistory, setCommandHistory] = useState<string[]>([]);

  const addToHistory = (command: string) => {
    setCommandHistory(prev => [...prev, command]);
  };

  const handleAnalyze = async (formData: ServiceParameters) => {
    try {
      setError(null);
      addToHistory(`analyze-service --name "${formData.name}"`);
      
      // First analyze the parameters
      const response = await analyzeParameters(formData);
      
      // Generate context ID and service name
      const contextId = Math.floor(Math.random() * 1000) + 1;
      const logServiceName = formData.name.toLowerCase().replace(/\s+/g, '-');
      
      addToHistory(`build-context --id ${contextId} --service "${logServiceName}"`);
      
      // Automatically build context
      const buildResponse = await buildContext({
        context_id: contextId,
        vm_id: null,
        'logs.service_name': logServiceName
      });

      setCloudinaryUrl(buildResponse.cloudinary_url);
      setSuccess(true);
      onAnalyzed(response);
      
      addToHistory('context-build-complete ✓');
    } catch (err) {
      const message = err instanceof Error ? err.message : 'An unexpected error occurred';
      setError(message);
      console.error('Failed to analyze parameters:', err);
      addToHistory('context-build-failed ✗');
    }
  };

  return (
    <div className="space-y-6">
      {/* Command History */}
      <div className="space-y-4">
        {commandHistory.map((command, index) => (
          <CommandPrompt
            key={index}
            command={command}
            output={command.includes('complete') ? 'Context document generated successfully' : 'Command executed successfully'}
          />
        ))}
      </div>

      {!success ? (
        <ServiceForm onSubmit={handleAnalyze} />
      ) : (
        <SuccessMessage
          title="Context Document Created!"
          message="Your service context has been analyzed and the context document has been generated successfully."
          link={cloudinaryUrl || ''}
        />
      )}

      {error && (
        <ErrorMessage
          title="Analysis Failed"
          message={error}
          onRetry={() => setError(null)}
        />
      )}
    </div>
  );
}