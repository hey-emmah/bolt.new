import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '../../lib/utils';
import { WizardStep } from '../../store/wizard';

interface ProgressProps {
  steps: { id: WizardStep; label: string }[];
  currentStep: WizardStep;
  onStepClick: (step: WizardStep) => void;
}

export function Progress({ steps, currentStep, onStepClick }: ProgressProps) {
  const currentIndex = steps.findIndex((step) => step.id === currentStep);

  return (
    <div className="w-full max-w-3xl mx-auto mb-8">
      <div className="relative">
        {/* Progress bar background */}
        <div className="absolute top-5 left-0 w-full h-1 bg-gray-200 rounded-full overflow-hidden">
          {/* Animated progress */}
          <motion.div
            className="h-full bg-gradient-to-r from-blue-500 to-blue-600"
            initial={{ width: '0%' }}
            animate={{ width: `${(currentIndex / (steps.length - 1)) * 100}%` }}
            transition={{ duration: 0.5, ease: "easeInOut" }}
          />
        </div>

        {/* Steps */}
        <div className="relative flex justify-between">
          {steps.map((step, index) => {
            const isCompleted = index <= currentIndex;
            const isCurrent = step.id === currentStep;

            return (
              <motion.button
                key={step.id}
                onClick={() => onStepClick(step.id)}
                className="flex flex-col items-center"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <motion.div
                  className={cn(
                    'w-10 h-10 rounded-full flex items-center justify-center font-mono transition-colors relative',
                    isCompleted ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-500'
                  )}
                  animate={{
                    scale: isCurrent ? 1.1 : 1,
                    boxShadow: isCurrent ? '0 0 0 4px rgba(59, 130, 246, 0.2)' : '0 0 0 0px rgba(59, 130, 246, 0)'
                  }}
                >
                  {index + 1}
                  {isCompleted && (
                    <motion.div
                      className="absolute inset-0 bg-blue-600 rounded-full"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ duration: 0.2 }}
                    />
                  )}
                </motion.div>
                <motion.span
                  className="mt-2 text-sm font-medium"
                  animate={{
                    color: isCurrent ? '#1E40AF' : '#6B7280'
                  }}
                >
                  {step.label}
                </motion.span>
              </motion.button>
            );
          })}
        </div>
      </div>
    </div>
  );
}