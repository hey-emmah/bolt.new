import React from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';

interface SuccessMessageProps {
  title: string;
  message: string;
  link?: string;
}

export function SuccessMessage({ title, message, link }: SuccessMessageProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ type: "spring", duration: 0.5 }}
      className="mt-6 p-6 bg-gradient-to-r from-green-50 to-emerald-50 border border-green-100 rounded-xl"
    >
      <motion.div
        initial={{ x: -20, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="flex items-center gap-3"
      >
        <motion.div
          whileHover={{ rotate: 360 }}
          transition={{ duration: 0.5 }}
          className="p-2 bg-green-100 rounded-lg"
        >
          <Check className="w-5 h-5 text-green-600" />
        </motion.div>
        <h3 className="text-lg font-medium text-green-900">{title}</h3>
      </motion.div>
      <motion.p
        initial={{ y: 10, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="text-sm text-green-700 mt-2 ml-12"
      >
        {message}
      </motion.p>
      {link && (
        <motion.a
          href={link}
          target="_blank"
          rel="noopener noreferrer"
          initial={{ y: 10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="mt-3 ml-12 inline-flex items-center gap-2 text-blue-600 hover:text-blue-800 font-mono text-sm bg-white/50 px-4 py-2 rounded-lg hover:bg-white/80 transition-colors"
        >
          <span>View Document</span>
          <motion.svg
            className="w-4 h-4"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            whileHover={{ x: 2 }}
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
          </motion.svg>
        </motion.a>
      )}
    </motion.div>
  );
}