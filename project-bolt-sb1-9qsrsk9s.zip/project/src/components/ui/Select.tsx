import React from 'react';
import { cn } from '../../lib/utils';

interface SelectOption {
  value: string;
  label: string;
}

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label: string;
  options: SelectOption[];
}

export function Select({ label, options, className, ...props }: SelectProps) {
  return (
    <div className="space-y-2">
      <label className="block text-sm text-gray-400">
        {label}
      </label>
      <select
        className={cn(
          "w-full px-4 py-2 bg-[#1E1E1E] border border-gray-700 rounded-lg",
          "text-green-400 placeholder-gray-600",
          "focus:ring-2 focus:ring-green-500/50 focus:border-green-500",
          "transition-all duration-200",
          className
        )}
        {...props}
      >
        {options.map(option => (
          <option key={option.value} value={option.value} className="bg-[#1E1E1E]">
            {option.label}
          </option>
        ))}
      </select>
    </div>
  );
}