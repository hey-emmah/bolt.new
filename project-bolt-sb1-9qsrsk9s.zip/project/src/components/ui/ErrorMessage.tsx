import React from 'react';
import { motion } from 'framer-motion';
import { AlertCircle } from 'lucide-react';

interface ErrorMessageProps {
  title: string;
  message: string;
  onRetry?: () => void;
}

export function ErrorMessage({ title, message, onRetry }: ErrorMessageProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ type: "spring", duration: 0.5 }}
      className="mt-6 p-6 bg-gradient-to-r from-red-50 to-rose-50 border border-red-100 rounded-xl"
    >
      <motion.div
        initial={{ x: -20, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="flex items-center gap-3"
      >
        <motion.div
          whileHover={{ rotate: 360 }}
          transition={{ duration: 0.5 }}
          className="p-2 bg-red-100 rounded-lg"
        >
          <AlertCircle className="w-5 h-5 text-red-600" />
        </motion.div>
        <h3 className="text-lg font-medium text-red-900">{title}</h3>
      </motion.div>
      <motion.p
        initial={{ y: 10, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="text-sm text-red-700 mt-2 ml-12"
      >
        {message}
      </motion.p>
      {onRetry && (
        <motion.button
          onClick={onRetry}
          initial={{ y: 10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="mt-3 ml-12 inline-flex items-center gap-2 text-red-600 hover:text-red-800 font-medium text-sm bg-white/50 px-4 py-2 rounded-lg hover:bg-white/80 transition-colors"
        >
          Try Again
        </motion.button>
      )}
    </motion.div>
  );
}