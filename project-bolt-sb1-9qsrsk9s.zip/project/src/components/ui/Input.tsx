import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '../../lib/utils';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement | HTMLTextAreaElement> {
  label: string;
  type?: string;
}

export function Input({ label, type = 'text', className, ...props }: InputProps) {
  const inputClasses = cn(
    "w-full px-4 py-2 bg-[#1E1E1E] border border-gray-700 rounded-lg",
    "text-green-400 placeholder-gray-600",
    "focus:ring-2 focus:ring-green-500/50 focus:border-green-500",
    "transition-all duration-200",
    className
  );
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-2"
    >
      <motion.label
        initial={{ opacity: 0, x: -10 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 0.1, duration: 0.3 }}
        className="block text-sm text-gray-400"
      >
        {label}
      </motion.label>
      {type === 'textarea' ? (
        <textarea
          className={inputClasses}
          rows={3}
          {...props}
        />
      ) : (
        <input
          type={type}
          className={inputClasses}
          {...props}
        />
      )}
    </motion.div>
  );
}