import React from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';

interface CheckboxProps {
  label: string;
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
}

export function Checkbox({ label, checked, onCheckedChange }: CheckboxProps) {
  return (
    <motion.label
      className="flex items-center gap-3 py-2 px-4 rounded-lg hover:bg-[#2D2D2D] transition-colors cursor-pointer group"
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
    >
      <motion.div className="relative">
        <input
          type="checkbox"
          checked={checked}
          onChange={(e) => onCheckedChange(e.target.checked)}
          className="sr-only"
        />
        <motion.div
          className={`w-5 h-5 border-2 rounded flex items-center justify-center ${
            checked ? 'border-green-500 bg-green-500/20' : 'border-gray-600'
          }`}
          animate={{
            borderColor: checked ? '#22C55E' : '#4B5563',
            backgroundColor: checked ? 'rgba(34, 197, 94, 0.2)' : 'transparent'
          }}
        >
          {checked && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0 }}
            >
              <Check className="w-3 h-3 text-green-500" />
            </motion.div>
          )}
        </motion.div>
      </motion.div>
      <span className="text-sm text-gray-400 group-hover:text-gray-300">{label}</span>
    </motion.label>
  );
}