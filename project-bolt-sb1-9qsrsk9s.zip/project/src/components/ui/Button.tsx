import React, { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { Loader2, ArrowLeft, ArrowRight } from 'lucide-react';
import { cn } from '../../lib/utils';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  loading?: boolean;
  variant?: 'primary' | 'ghost';
  direction?: 'back' | 'next' | 'none';
  icon?: ReactNode;
}

export function Button({ 
  children, 
  loading, 
  variant = 'primary',
  direction = 'none',
  icon,
  className,
  ...props 
}: ButtonProps) {
  const variants = {
    primary: "bg-gradient-to-r from-green-400 to-green-500 hover:from-green-500 hover:to-green-600 text-white shadow-lg shadow-green-500/20",
    ghost: "bg-[#2D2D2D] text-gray-300 hover:bg-[#363636] hover:text-white"
  };

  const getIcon = () => {
    if (loading) return <Loader2 className="w-4 h-4 animate-spin" />;
    if (icon) return icon;
    if (direction === 'back') return <ArrowLeft className="w-4 h-4" />;
    if (direction === 'next') return <ArrowRight className="w-4 h-4" />;
    return null;
  };

  return (
    <motion.button
      className={cn(
        "px-6 py-2.5 rounded-lg font-medium transition-all duration-200",
        "flex items-center justify-center gap-2",
        "focus:outline-none focus:ring-2 focus:ring-green-500/50",
        "disabled:opacity-50 disabled:cursor-not-allowed",
        variants[variant],
        className
      )}
      disabled={loading}
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      {...props}
    >
      {getIcon()}
      {children}
    </motion.button>
  );
}