import React, { useState } from 'react';
import { Terminal } from 'lucide-react';

export function GuacamoleConnection() {
  const [connectionName, setConnectionName] = useState('');
  const [password, setPassword] = useState('');
  const [isFullScreen, setIsFullScreen] = useState(false);

  const handleConnect = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle connection logic
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 max-w-xl mx-auto mt-8">
      <div className="flex items-center gap-2 mb-6">
        <Terminal className="w-6 h-6 text-blue-600" />
        <h2 className="text-2xl font-bold text-gray-800">Guacamole Connection</h2>
      </div>

      <form onSubmit={handleConnect} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Connection Name
          </label>
          <input
            type="text"
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            value={connectionName}
            onChange={(e) => setConnectionName(e.target.value)}
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Password
          </label>
          <input
            type="password"
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
        >
          Connect
        </button>
      </form>

      <div className="mt-6">
        <div className="relative bg-black rounded-lg overflow-hidden" style={{ height: isFullScreen ? '100vh' : '400px' }}>
          <div className="absolute top-2 right-2">
            <button
              onClick={() => setIsFullScreen(!isFullScreen)}
              className="bg-gray-800 text-white px-3 py-1 rounded-md text-sm hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-500"
            >
              {isFullScreen ? 'Exit Full Screen' : 'Full Screen'}
            </button>
          </div>
          <div className="w-full h-full bg-black text-green-500 p-4 font-mono">
            {/* SSH Terminal would be embedded here */}
            <p>Connected to: {connectionName || 'Not connected'}</p>
          </div>
        </div>
      </div>
    </div>
  );
}