import React from 'react';
import { motion } from 'framer-motion';
import { Settings2 } from 'lucide-react';
import { useWizardStore } from '../../store/wizard';

const platformTypes = ['Container', 'VM', 'Serverless'];
const environments = ['Development', 'Staging', 'Production'];

export function ParametersStep() {
  const { data, updateData } = useWizardStore();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-6"
    >
      <div className="flex items-center gap-3 mb-6">
        <div className="p-3 bg-green-100 rounded-lg">
          <Settings2 className="w-6 h-6 text-green-600" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Service Parameters</h2>
          <p className="text-gray-500">Configure your service settings</p>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Service Name
          </label>
          <input
            type="text"
            placeholder="Enter service name"
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono"
            value={data.parameters.serviceName}
            onChange={(e) => updateData('parameters', { serviceName: e.target.value })}
            required
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Platform Type
            </label>
            <select
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono"
              value={data.parameters.platformType}
              onChange={(e) => updateData('parameters', { platformType: e.target.value })}
              required
            >
              <option value="">Select type</option>
              {platformTypes.map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Environment
            </label>
            <select
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono"
              value={data.parameters.environment}
              onChange={(e) => updateData('parameters', { environment: e.target.value })}
              required
            >
              <option value="">Select environment</option>
              {environments.map(env => (
                <option key={env} value={env}>{env}</option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </motion.div>
  );
}