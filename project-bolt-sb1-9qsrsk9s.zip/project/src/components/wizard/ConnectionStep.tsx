import React from 'react';
import { motion } from 'framer-motion';
import { Terminal } from 'lucide-react';
import { useWizardStore } from '../../store/wizard';

export function ConnectionStep() {
  const { data, updateData } = useWizardStore();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-6"
    >
      <div className="flex items-center gap-3 mb-6">
        <div className="p-3 bg-yellow-100 rounded-lg">
          <Terminal className="w-6 h-6 text-yellow-600" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Connection Setup</h2>
          <p className="text-gray-500">Configure your remote access settings</p>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Connection Name
          </label>
          <input
            type="text"
            placeholder="Enter connection name"
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono"
            value={data.connection.connectionName}
            onChange={(e) => updateData('connection', { connectionName: e.target.value })}
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Connection Password
          </label>
          <input
            type="password"
            placeholder="Enter connection password"
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono"
            value={data.connection.password}
            onChange={(e) => updateData('connection', { password: e.target.value })}
            required
          />
        </div>
      </div>
    </motion.div>
  );
}