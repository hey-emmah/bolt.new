import React from 'react';
import { motion } from 'framer-motion';
import { Cpu, HardDrive, CircleEqual } from 'lucide-react';
import { useWizardStore } from '../../store/wizard';

export function ResourcesStep() {
  const { data, updateData } = useWizardStore();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="space-y-6"
    >
      <div className="flex items-center gap-3 mb-6">
        <div className="p-3 bg-purple-100 rounded-lg">
          <Cpu className="w-6 h-6 text-purple-600" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Resource Allocation</h2>
          <p className="text-gray-500">Configure your VM resources</p>
        </div>
      </div>

      <div className="grid gap-6">
        <div className="resource-input">
          <div className="flex items-center gap-2 mb-2">
            <CircleEqual className="w-4 h-4 text-gray-500" />
            <label className="text-sm font-medium text-gray-700">Memory (MB)</label>
          </div>
          <input
            type="range"
            min="512"
            max="65536"
            step="512"
            className="w-full"
            value={data.resources.memory}
            onChange={(e) => updateData('resources', { memory: parseInt(e.target.value) })}
          />
          <div className="mt-1 text-sm text-gray-500 font-mono">{data.resources.memory} MB</div>
        </div>

        <div className="resource-input">
          <div className="flex items-center gap-2 mb-2">
            <Cpu className="w-4 h-4 text-gray-500" />
            <label className="text-sm font-medium text-gray-700">vCPUs</label>
          </div>
          <input
            type="range"
            min="1"
            max="32"
            className="w-full"
            value={data.resources.vcpus}
            onChange={(e) => updateData('resources', { vcpus: parseInt(e.target.value) })}
          />
          <div className="mt-1 text-sm text-gray-500 font-mono">{data.resources.vcpus} vCPUs</div>
        </div>

        <div className="resource-input">
          <div className="flex items-center gap-2 mb-2">
            <HardDrive className="w-4 h-4 text-gray-500" />
            <label className="text-sm font-medium text-gray-700">Disk Size (GB)</label>
          </div>
          <input
            type="range"
            min="10"
            max="2048"
            className="w-full"
            value={data.resources.diskSize}
            onChange={(e) => updateData('resources', { diskSize: parseInt(e.target.value) })}
          />
          <div className="mt-1 text-sm text-gray-500 font-mono">{data.resources.diskSize} GB</div>
        </div>
      </div>
    </motion.div>
  );
}