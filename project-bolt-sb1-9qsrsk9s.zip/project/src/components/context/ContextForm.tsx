import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { buildContext } from '../../lib/api';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';

interface ContextFormProps {
  requiredParameters: string[];
  contextId: string;
  onSuccess: () => void;
}

export function ContextForm({ requiredParameters, contextId, onSuccess }: ContextFormProps) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<Record<string, string>>({});

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const requestBody = {
        context_id: contextId,
        ...Object.fromEntries(
          Object.entries(formData).map(([key, value]) => [
            key.toLowerCase().replace(/\s+/g, '_'),
            value
          ])
        )
      };

      await buildContext(requestBody);
      onSuccess();
    } catch (error) {
      console.error('Failed to build context:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.form
      onSubmit={handleSubmit}
      className="space-y-6"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
    >
      {requiredParameters.map(param => (
        <Input
          key={param}
          label={param.split('.').join(' ').replace(/^\w/, c => c.toUpperCase())}
          value={formData[param] || ''}
          onChange={(e) => setFormData(prev => ({ ...prev, [param]: e.target.value }))}
          required
        />
      ))}

      <Button
        type="submit"
        loading={loading}
        className="w-full"
      >
        Build Context
      </Button>
    </motion.form>
  );
}