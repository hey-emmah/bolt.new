import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronRight } from 'lucide-react';
import { Input } from '../ui/Input';
import { AnalyzeResponse } from '../../types/api';

interface ContextParametersFormProps {
  parameters: string[];
  onBuildContext: (params: Record<string, string>) => Promise<void>;
}

export function ContextParametersForm({ parameters, onBuildContext }: ContextParametersFormProps) {
  const [formData, setFormData] = useState<Record<string, string>>({});

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onBuildContext(formData);
  };

  const handleInputChange = (key: string, value: string) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {parameters.map(param => (
        <Input
          key={param}
          label={param}
          value={formData[param] || ''}
          onChange={(e) => handleInputChange(param, e.target.value)}
          required
        />
      ))}

      <motion.button
        type="submit"
        className="flex items-center gap-2 px-4 py-2 bg-blue-500/10 text-blue-400 rounded-lg hover:bg-blue-500/20 transition-colors"
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
      >
        Build Context
        <ChevronRight className="w-4 h-4" />
      </motion.button>
    </form>
  );
}