import React, { useState } from 'react';
import { FileJson } from 'lucide-react';
import { ContextForm } from './ContextForm';
import { CommandPrompt } from '../terminal/CommandPrompt';
import { AnalyzeResponse } from '../../types/service';

interface ContextBuilderProps {
  serviceResponse: AnalyzeResponse;
  onComplete: () => void;
}

export function ContextBuilder({ serviceResponse, onComplete }: ContextBuilderProps) {
  const [isComplete, setIsComplete] = useState(false);

  const handleSuccess = () => {
    setIsComplete(true);
    // Delay the transition slightly to show the success message
    setTimeout(onComplete, 1500);
  };

  return (
    <div className="space-y-6">
      {!isComplete ? (
        <>
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-[#2D2D2D] rounded-lg">
              <FileJson className="w-5 h-5 text-green-400" />
            </div>
            <div>
              <h2 className="text-green-400 font-bold">Context Builder</h2>
              <p className="text-gray-500 text-sm">
                Configuring {serviceResponse.context_type} context parameters
              </p>
            </div>
          </div>

          <ContextForm
            requiredParameters={serviceResponse.required_parameters}
            contextId={serviceResponse.context_id}
            onSuccess={handleSuccess}
          />
        </>
      ) : (
        <CommandPrompt
          command="context-build"
          output={`Service context with id ${serviceResponse.context_id} generated successfully`}
        />
      )}
    </div>
  );
}