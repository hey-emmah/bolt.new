import React, { useState } from 'react';
import { FileJson, ArrowLeft } from 'lucide-react';
import { buildContext } from '../lib/api';

interface ContextBuilderProps {
  requiredParameters: string[];
  contextType: 'new' | 'existing';
  onReset: () => void;
}

export function ContextBuilder({ requiredParameters, contextType, onReset }: ContextBuilderProps) {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [cloudinaryUrl, setCloudinaryUrl] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    context_id: '',
    vm_id: '',
    'logs.service_name': ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await buildContext({
        context_id: parseInt(formData.context_id),
        vm_id: parseInt(formData.vm_id),
        'logs.service_name': formData['logs.service_name']
      });
      setCloudinaryUrl(response.cloudinary_url);
      setSuccess(true);
    } catch (error) {
      console.error('Failed to build context:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-8">
      <div className="flex items-center gap-3 mb-8">
        <div className="p-3 bg-green-100 rounded-lg">
          <FileJson className="w-6 h-6 text-green-600" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Context Builder</h2>
          <p className="text-gray-500">Configure required parameters for {contextType} context</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid gap-6 md:grid-cols-2">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Context ID
            </label>
            <input
              type="number"
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono"
              value={formData.context_id}
              onChange={(e) => setFormData({ ...formData, context_id: e.target.value })}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              VM ID
            </label>
            <input
              type="number"
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono"
              value={formData.vm_id}
              onChange={(e) => setFormData({ ...formData, vm_id: e.target.value })}
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Logs Service Name
          </label>
          <input
            type="text"
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 font-mono"
            value={formData['logs.service_name']}
            onChange={(e) => setFormData({ ...formData, 'logs.service_name': e.target.value })}
            required
          />
        </div>

        <div className="flex gap-4">
          <button
            type="button"
            onClick={onReset}
            className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:text-gray-900 focus:outline-none"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </button>

          <button
            type="submit"
            disabled={loading}
            className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-medium"
          >
            {loading ? 'Building Context...' : 'Build Context'}
          </button>
        </div>
      </form>

      {success && cloudinaryUrl && (
        <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-md">
          <h3 className="text-lg font-medium text-green-900 mb-2">Context Document Created!</h3>
          <p className="text-sm text-green-700">
            Your context document has been generated and uploaded. You can access it here:
          </p>
          <a
            href={cloudinaryUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-2 inline-block text-blue-600 hover:text-blue-800 font-mono text-sm"
          >
            {cloudinaryUrl}
          </a>
        </div>
      )}
    </div>
  );
}