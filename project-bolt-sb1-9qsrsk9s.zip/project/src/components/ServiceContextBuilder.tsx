import React, { useState } from 'react';
import { ServiceAnalyzer } from './service/ServiceAnalyzer';
import { ContextBuilder } from './context/ContextBuilder';
import { ObservabilityProvisioning } from './observability/ObservabilityProvisioning';
import { MachineProvisioning } from './machine/MachineProvisioning';
import { AnalyzeResponse } from '../types/service';

export function ServiceContextBuilder() {
  const [currentStage, setCurrentStage] = useState<'analyze' | 'context' | 'machine' | 'observability'>('analyze');
  const [analyzeResponse, setAnalyzeResponse] = useState<AnalyzeResponse | null>(null);

  const handleAnalyzeComplete = (response: AnalyzeResponse) => {
    setAnalyzeResponse(response);
    setCurrentStage('context');
  };

  const handleContextComplete = () => {
    setCurrentStage('machine');
  };

  const handleMachineComplete = () => {
    setCurrentStage('observability');
  };

  return (
    <div className="space-y-8">
      {currentStage === 'analyze' && (
        <ServiceAnalyzer onAnalyzed={handleAnalyzeComplete} />
      )}
      
      {currentStage === 'context' && analyzeResponse && (
        <ContextBuilder 
          serviceResponse={analyzeResponse}
          onComplete={handleContextComplete}
        />
      )}

      {currentStage === 'machine' && (
        <MachineProvisioning onComplete={handleMachineComplete} />
      )}
      
      {currentStage === 'observability' && (
        <ObservabilityProvisioning />
      )}
    </div>
  );
}