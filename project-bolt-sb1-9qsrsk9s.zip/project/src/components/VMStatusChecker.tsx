import React, { useState } from 'react';
import { Server, AlertCircle, CheckCircle, XCircle } from 'lucide-react';

interface VMStatus {
  id: string;
  name: string;
  status: 'running' | 'stopped' | 'error';
  ipAddress: string;
  errorMessage?: string;
}

export function VMStatusChecker() {
  const [vmId, setVmId] = useState('');
  const [status, setStatus] = useState<VMStatus | null>(null);

  const handleCheck = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulated status check
    setStatus({
      id: vmId,
      name: 'Test VM',
      status: 'running',
      ipAddress: '192.168.1.100'
    });
  };

  const getStatusBadge = (status: string) => {
    const badges = {
      running: { color: 'bg-green-100 text-green-800', icon: <CheckCircle className="w-4 h-4" /> },
      stopped: { color: 'bg-yellow-100 text-yellow-800', icon: <AlertCircle className="w-4 h-4" /> },
      error: { color: 'bg-red-100 text-red-800', icon: <XCircle className="w-4 h-4" /> }
    };

    const badge = badges[status as keyof typeof badges];
    return (
      <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-sm font-medium ${badge.color}`}>
        {badge.icon}
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </span>
    );
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 max-w-xl mx-auto mt-8">
      <div className="flex items-center gap-2 mb-6">
        <Server className="w-6 h-6 text-blue-600" />
        <h2 className="text-2xl font-bold text-gray-800">VM Status Checker</h2>
      </div>

      <form onSubmit={handleCheck} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            VM ID
          </label>
          <input
            type="text"
            placeholder="Enter VM ID"
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            value={vmId}
            onChange={(e) => setVmId(e.target.value)}
            required
          />
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
        >
          Check Status
        </button>
      </form>

      {status && (
        <div className="mt-6 p-4 bg-gray-50 rounded-md">
          <h3 className="text-lg font-medium text-gray-900 mb-4">VM Details</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Name:</span>
              <span className="font-medium">{status.name}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Status:</span>
              {getStatusBadge(status.status)}
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">IP Address:</span>
              <span className="font-medium">{status.ipAddress}</span>
            </div>
            {status.errorMessage && (
              <div className="flex justify-between text-red-600">
                <span>Error:</span>
                <span>{status.errorMessage}</span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}