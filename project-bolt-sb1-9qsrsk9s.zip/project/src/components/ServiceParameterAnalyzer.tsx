import React, { useState } from 'react';
import { Settings, AlertCircle } from 'lucide-react';

interface ServiceParameters {
  serviceName: string;
  description: string;
  platformName: string;
  platformType: string;
  environment: string;
  dependencies: string[];
  observabilityEnabled: boolean;
  onCallContacts: string[];
}

export function ServiceParameterAnalyzer() {
  const [parameters, setParameters] = useState<ServiceParameters>({
    serviceName: '',
    description: '',
    platformName: '',
    platformType: '',
    environment: '',
    dependencies: [],
    observabilityEnabled: false,
    onCallContacts: []
  });

  const platformTypes = ['Container', 'VM', 'Serverless'];
  const environments = ['Development', 'Staging', 'Production'];
  const availableDependencies = ['Redis', 'PostgreSQL', 'MongoDB', 'ElasticSearch'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Service parameters:', parameters);
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 max-w-xl mx-auto mt-8">
      <div className="flex items-center gap-2 mb-6">
        <Settings className="w-6 h-6 text-blue-600" />
        <h2 className="text-2xl font-bold text-gray-800">Service Parameter Analyzer</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Service Name
          </label>
          <input
            type="text"
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            value={parameters.serviceName}
            onChange={(e) => setParameters({ ...parameters, serviceName: e.target.value })}
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Description
          </label>
          <textarea
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            rows={3}
            value={parameters.description}
            onChange={(e) => setParameters({ ...parameters, description: e.target.value })}
            required
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Platform Type
            </label>
            <select
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              value={parameters.platformType}
              onChange={(e) => setParameters({ ...parameters, platformType: e.target.value })}
              required
            >
              <option value="">Select type</option>
              {platformTypes.map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Environment
            </label>
            <select
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              value={parameters.environment}
              onChange={(e) => setParameters({ ...parameters, environment: e.target.value })}
              required
            >
              <option value="">Select environment</option>
              {environments.map(env => (
                <option key={env} value={env}>{env}</option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Dependencies
          </label>
          <div className="space-y-2">
            {availableDependencies.map(dep => (
              <label key={dep} className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={parameters.dependencies.includes(dep)}
                  onChange={(e) => {
                    const newDeps = e.target.checked
                      ? [...parameters.dependencies, dep]
                      : parameters.dependencies.filter(d => d !== dep);
                    setParameters({ ...parameters, dependencies: newDeps });
                  }}
                  className="rounded text-blue-600 focus:ring-blue-500"
                />
                <span className="text-sm text-gray-700">{dep}</span>
              </label>
            ))}
          </div>
        </div>

        <div>
          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={parameters.observabilityEnabled}
              onChange={(e) => setParameters({ ...parameters, observabilityEnabled: e.target.checked })}
              className="rounded text-blue-600 focus:ring-blue-500"
            />
            <span className="text-sm font-medium text-gray-700">Enable Observability Tools</span>
          </label>
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
        >
          Analyze Parameters
        </button>
      </form>
    </div>
  );
}