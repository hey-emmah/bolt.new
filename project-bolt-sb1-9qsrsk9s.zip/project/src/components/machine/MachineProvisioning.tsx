import React from 'react';
import { useMachineProvisioning } from '../../hooks/useMachineProvisioning';
import { MachineProvisioningForm } from './MachineProvisioningForm';
import { MachineStatus } from './MachineStatus';

interface MachineProvisioningProps {
  onComplete: () => void;
}

export function MachineProvisioning({ onComplete }: MachineProvisioningProps) {
  const {
    status,
    isProvisioning,
    error,
    startProvisioning
  } = useMachineProvisioning({
    onProvisioningComplete: onComplete
  });

  if (error) {
    return (
      <div className="text-red-400 bg-red-500/10 px-4 py-3 rounded-lg border border-red-500/20">
        {error}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {!isProvisioning && !status && (
        <MachineProvisioningForm onSubmit={startProvisioning} />
      )}
      
      {(isProvisioning || status) && (
        <MachineStatus status={status} isProvisioning={isProvisioning} />
      )}
    </div>
  );
}