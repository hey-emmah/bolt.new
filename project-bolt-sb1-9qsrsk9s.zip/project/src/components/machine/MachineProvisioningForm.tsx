import React from 'react';
import { motion } from 'framer-motion';
import { Server } from 'lucide-react';
import { Button } from '../ui/Button';

interface MachineProvisioningFormProps {
  onSubmit: () => void;
}

export function MachineProvisioningForm({ onSubmit }: MachineProvisioningFormProps) {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit();
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="flex items-center gap-3 mb-4">
        <div className="p-2 bg-[#2D2D2D] rounded-lg">
          <Server className="w-5 h-5 text-green-400" />
        </div>
        <div>
          <h2 className="text-green-400 font-bold">Machine Provisioning</h2>
          <p className="text-gray-500 text-sm">
            Provision a dedicated machine for your service
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <Button type="submit" className="w-full">
          Start Machine Provisioning
        </Button>
      </form>
    </motion.div>
  );
}