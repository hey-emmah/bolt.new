import React from 'react';
import { motion } from 'framer-motion';
import { Loader2, CheckCircle2 } from 'lucide-react';
import { ProvisioningStatusType } from '../../types/machine';

interface MachineStatusProps {
  status: ProvisioningStatusType | null;
  isProvisioning: boolean;
}

export function MachineStatus({ status, isProvisioning }: MachineStatusProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      {isProvisioning && !status && (
        <div className="flex items-center gap-3 text-blue-400">
          <Loader2 className="w-5 h-5 animate-spin" />
          <span>Provisioning dedicated machine...</span>
        </div>
      )}

      {status === 'success' && (
        <div className="flex items-center gap-3 text-green-400">
          <CheckCircle2 className="w-5 h-5" />
          <span>Machine provisioned successfully</span>
        </div>
      )}
    </motion.div>
  );
}