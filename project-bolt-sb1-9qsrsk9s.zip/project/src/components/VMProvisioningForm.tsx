import React, { useState } from 'react';
import { AlertCircle, Server, Check } from 'lucide-react';

interface VMProvisioningFormProps {
  onSubmit: (data: VMFormData) => void;
}

export interface VMFormData {
  businessName: string;
  memory: number;
  vcpus: number;
  diskSize: number;
}

export function VMProvisioningForm({ onSubmit }: VMProvisioningFormProps) {
  const [formData, setFormData] = useState<VMFormData>({
    businessName: '',
    memory: 1024,
    vcpus: 2,
    diskSize: 20
  });
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
    setSuccess(true);
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 max-w-xl mx-auto">
      <div className="flex items-center gap-2 mb-6">
        <Server className="w-6 h-6 text-blue-600" />
        <h2 className="text-2xl font-bold text-gray-800">Provision New VM</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Business Name
          </label>
          <input
            type="text"
            placeholder="Enter your business name"
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            value={formData.businessName}
            onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Memory (MB)
          </label>
          <input
            type="number"
            min="512"
            max="65536"
            step="512"
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            value={formData.memory}
            onChange={(e) => setFormData({ ...formData, memory: parseInt(e.target.value) })}
            required
          />
          <p className="text-sm text-gray-500 mt-1">Range: 512MB - 65536MB</p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            vCPUs
          </label>
          <input
            type="number"
            min="1"
            max="32"
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            value={formData.vcpus}
            onChange={(e) => setFormData({ ...formData, vcpus: parseInt(e.target.value) })}
            required
          />
          <p className="text-sm text-gray-500 mt-1">Range: 1-32 vCPUs</p>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Disk Size (GB)
          </label>
          <input
            type="number"
            min="10"
            max="2048"
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            value={formData.diskSize}
            onChange={(e) => setFormData({ ...formData, diskSize: parseInt(e.target.value) })}
            required
          />
          <p className="text-sm text-gray-500 mt-1">Range: 10GB - 2048GB</p>
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
        >
          Provision VM
        </button>
      </form>

      {success && (
        <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-md">
          <div className="flex items-center gap-2">
            <Check className="w-5 h-5 text-green-600" />
            <p className="text-green-700 font-medium">VM Provisioning Started</p>
          </div>
          <div className="mt-2 text-sm text-green-600">
            Your VM is being provisioned with the specified configuration.
          </div>
        </div>
      )}
    </div>
  );
}