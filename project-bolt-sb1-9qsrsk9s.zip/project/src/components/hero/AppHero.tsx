import React from 'react';
import { Terminal, Zap } from 'lucide-react';

export function AppHero() {
  return (
    <div className="mb-8">
      <div className="mb-8 animate-pulse">
        <span className="text-green-400">$</span>
        <span className="ml-2 text-gray-400">initializing clete...</span>
      </div>

      <div className="space-y-6">
        <div className="flex items-center gap-3 text-xl">
          <div className="relative">
            <Terminal className="w-6 h-6" />
            <Zap className="w-4 h-4 text-yellow-400 absolute -top-1 -right-1" />
          </div>
          <h1 className="font-bold">Clete v0.1.0-alpha</h1>
        </div>

        <div className="text-gray-400 border-l-2 border-gray-700 pl-4 py-2">
          <p className="mb-2">
            AI agent that proactively detects and debugs issues, delivering root cause analysis before escalation.
          </p>
          <p className="text-sm text-gray-500 mb-4">
            Built with ⚡ for teams who prefer realtime visibility over last-minute firefighting.
          </p>
        </div>
      </div>
    </div>
  );
}