import React from 'react';

export function TerminalHeader() {
  return (
    <div className="bg-[#2D2D2D] rounded-t-lg p-3 flex items-center">
      <div className="flex space-x-2">
        <div className="w-3 h-3 rounded-full bg-red-500" />
        <div className="w-3 h-3 rounded-full bg-yellow-500" />
        <div className="w-3 h-3 rounded-full bg-green-500" />
      </div>
      <div className="flex-1 text-center text-sm text-gray-400">
        clete -- /usr/local/bin/clete
      </div>
    </div>
  );
}