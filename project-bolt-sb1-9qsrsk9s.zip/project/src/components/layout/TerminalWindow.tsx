import React, { ReactNode } from 'react';
import { TerminalHeader } from './TerminalHeader';

interface TerminalWindowProps {
  children: ReactNode;
}

export function TerminalWindow({ children }: TerminalWindowProps) {
  return (
    <div className="max-w-6xl mx-auto p-4 sm:p-6 lg:p-8">
      <TerminalHeader />
      <div className="bg-[#1E1E1E] border border-[#2D2D2D] rounded-b-lg p-6">
        {children}
      </div>
    </div>
  );
}