import React from 'react';
import { useObservabilityProvisioning } from '../../hooks/useObservabilityProvisioning';
import { ProvisioningStatus } from './ProvisioningStatus';
import { ProvisioningButton } from './ProvisioningButton';

export function ObservabilityProvisioning() {
  const { 
    status, 
    isProvisioning, 
    error, 
    startProvisioning 
  } = useObservabilityProvisioning();

  if (error) {
    return (
      <div className="text-red-400 bg-red-500/10 px-4 py-3 rounded-lg border border-red-500/20">
        {error}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {!isProvisioning && !status && (
        <ProvisioningButton onProvision={startProvisioning} />
      )}
      
      {(isProvisioning || status) && (
        <ProvisioningStatus status={status} isProvisioning={isProvisioning} />
      )}
    </div>
  );
}