import React from 'react';
import { motion } from 'framer-motion';
import { Server } from 'lucide-react';

interface ProvisioningButtonProps {
  onProvision: () => void;
}

export function ProvisioningButton({ onProvision }: ProvisioningButtonProps) {
  return (
    <motion.button
      onClick={onProvision}
      className="w-full bg-green-500/10 text-green-400 px-6 py-4 rounded-lg border border-green-500/20 
                 hover:bg-green-500/20 transition-colors flex items-center justify-center gap-3"
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
    >
      <Server className="w-5 h-5" />
      Provision Observability Machine
    </motion.button>
  );
}