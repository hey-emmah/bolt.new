import React from 'react';
import { motion } from 'framer-motion';
import { AnalyzeResponse, ServiceParameters } from '../../types/service';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';

interface ContextParametersFormProps {
  serviceResponse: AnalyzeResponse;
  onSubmit: (formData: ServiceParameters) => Promise<void>;
  loading?: boolean;
}

export function ContextParametersForm({ serviceResponse, onSubmit, loading }: ContextParametersFormProps) {
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    
    const formData: ServiceParameters = {
      name: '',
      description: '',
      platform: { name: '', type: '', environment: '' },
      dependencies: [],
      observability: {
        logs: {
          service_name: form['logs.service_name'].value
        }
      },
      on_call: []
    };

    await onSubmit(formData);
  };

  return (
    <motion.form
      onSubmit={handleSubmit}
      className="space-y-6"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
    >
      {serviceResponse.required_parameters.map(param => (
        <Input
          key={param}
          name={param}
          label={param}
          required
        />
      ))}

      <Button
        type="submit"
        loading={loading}
        className="w-full"
      >
        Build Context
      </Button>
    </motion.form>
  );
}