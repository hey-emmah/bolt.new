import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AnalyzeResponse } from '../../../types/service';
import { mockApi } from '../../../lib/mockApi';
import { Input } from '../../ui/Input';
import { Button } from '../../ui/Button';

interface ContextBuilderProps {
  serviceResponse: AnalyzeResponse;
  onCommand: (command: string, output?: string, status?: 'success' | 'error') => void;
}

export function ContextBuilder({ serviceResponse, onCommand }: ContextBuilderProps) {
  const [loading, setLoading] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [formData, setFormData] = useState<Record<string, string>>({});

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const requestBody = {
        context_id: serviceResponse.context_id,
        ...Object.fromEntries(
          Object.entries(formData).map(([key, value]) => [
            key.toLowerCase().replace(/\s+/g, '_'),
            value
          ])
        )
      };

      const response = await mockApi.buildContext(requestBody);
      onCommand('context-build', `Service context with id ${response.context_id} generated successfully`);
      setIsComplete(true);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to build context';
      onCommand('context-build-failed', message, 'error');
    } finally {
      setLoading(false);
    }
  };

  if (isComplete) {
    return null;
  }

  return (
    <AnimatePresence mode="wait">
      <motion.form
        onSubmit={handleSubmit}
        className="space-y-6"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -10 }}
      >
        {serviceResponse.required_parameters.map(param => (
          <Input
            key={param}
            label={param.split('.').join(' ').replace(/^\w/, c => c.toUpperCase())}
            value={formData[param] || ''}
            onChange={(e) => setFormData(prev => ({ ...prev, [param]: e.target.value }))}
            placeholder={`Enter ${param.split('.').join(' ')}`}
            required
          />
        ))}

        <Button
          type="submit"
          loading={loading}
          className="w-full"
        >
          Build Context
        </Button>
      </motion.form>
    </AnimatePresence>
  );
}