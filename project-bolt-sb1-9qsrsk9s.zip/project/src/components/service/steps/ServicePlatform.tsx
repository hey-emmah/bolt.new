import React from 'react';
import { motion } from 'framer-motion';
import { ChevronRight } from 'lucide-react';
import { StepProps } from '../../../types/service';
import { Input } from '../../ui/Input';
import { Select } from '../../ui/Select';

export function ServicePlatform({ data, onUpdate, onStepComplete }: StepProps) {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onStepComplete();
  };

  const updatePlatform = (key: string, value: string) => {
    onUpdate({
      platform: {
        ...data.platform,
        [key]: value
      }
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Input
        label="Platform Name"
        value={data.platform.name}
        onChange={(e) => updatePlatform('name', e.target.value)}
        placeholder="e.g., ECS Fargate"
        required
      />

      <div className="grid gap-6 md:grid-cols-2">
        <Select
          label="Platform Type"
          value={data.platform.type}
          onChange={(e) => updatePlatform('type', e.target.value)}
          options={[
            { value: '', label: 'Select type' },
            { value: 'Compute', label: 'Compute' },
            { value: 'Storage', label: 'Storage' },
            { value: 'Network', label: 'Network' },
          ]}
          required
        />

        <Select
          label="Environment"
          value={data.platform.environment}
          onChange={(e) => updatePlatform('environment', e.target.value)}
          options={[
            { value: '', label: 'Select environment' },
            { value: 'development', label: 'Development' },
            { value: 'staging', label: 'Staging' },
            { value: 'production', label: 'Production' },
          ]}
          required
        />
      </div>

      <motion.button
        type="submit"
        className="flex items-center gap-2 px-4 py-2 bg-green-500/10 text-green-400 rounded-lg hover:bg-green-500/20 transition-colors"
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
      >
        Next Step
        <ChevronRight className="w-4 h-4" />
      </motion.button>
    </form>
  );
}