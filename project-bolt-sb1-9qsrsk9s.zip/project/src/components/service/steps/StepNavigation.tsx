import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '../../ui/Button';

interface StepNavigationProps {
  isLastStep: boolean;
  onNext: () => void;
  onSubmit: () => void;
  loading?: boolean;
}

export function StepNavigation({ isLastStep, onNext, onSubmit, loading }: StepNavigationProps) {
  return (
    <div className="flex justify-end mt-6 gap-4">
      {!isLastStep ? (
        <Button
          onClick={onNext}
          variant="terminal"
          className="text-green-400"
        >
          Next Command
        </Button>
      ) : (
        <Button
          onClick={onSubmit}
          variant="terminal"
          className="text-blue-400"
          loading={loading}
        >
          {loading ? 'Analyzing...' : 'Run Analysis'}
        </Button>
      )}
    </div>
  );
}