import React from 'react';
import { motion } from 'framer-motion';
import { ChevronRight } from 'lucide-react';
import { StepProps } from '../../../types/service';
import { Input } from '../../ui/Input';

export function ServiceBasicInfo({ data, onUpdate, onStepComplete }: StepProps) {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onStepComplete();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Input
        label="Service Name"
        value={data.name}
        onChange={(e) => onUpdate({ name: e.target.value })}
        placeholder="e.g., payment-service"
        required
      />

      <Input
        label="Description"
        type="textarea"
        value={data.description}
        onChange={(e) => onUpdate({ description: e.target.value })}
        placeholder="Describe your service's primary function"
        required
      />

      <motion.button
        type="submit"
        className="flex items-center gap-2 px-4 py-2 bg-green-500/10 text-green-400 rounded-lg hover:bg-green-500/20 transition-colors"
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
      >
        Next Step
        <ChevronRight className="w-4 h-4" />
      </motion.button>
    </form>
  );
}