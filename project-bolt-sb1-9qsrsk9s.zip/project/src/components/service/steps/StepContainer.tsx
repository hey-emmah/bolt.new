import React, { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { ChevronRight } from 'lucide-react';

interface StepContainerProps {
  command: string;
  children: ReactNode;
}

export function StepContainer({ command, children }: StepContainerProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="bg-[#2D2D2D] rounded-lg p-6 border border-gray-700"
    >
      <div className="flex items-center gap-2 mb-4 text-green-400">
        <ChevronRight className="w-4 h-4" />
        <span className="text-sm font-mono">{command}</span>
      </div>
      <div className="space-y-6">
        {children}
      </div>
    </motion.div>
  );
}