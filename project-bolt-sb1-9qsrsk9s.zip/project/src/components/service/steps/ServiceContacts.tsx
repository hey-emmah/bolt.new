import React from 'react';
import { motion } from 'framer-motion';
import { ChevronRight } from 'lucide-react';
import { ContactsStepProps } from '../../../types/service';
import { Input } from '../../ui/Input';

export function ServiceContacts({ data, onUpdate, onStepComplete, onAnalyze }: ContactsStepProps) {
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    onStepComplete();
    onAnalyze();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Input
        label="On-Call Contacts"
        placeholder="Enter email addresses separated by commas"
        value={data.on_call.join(', ')}
        onChange={(e) => onUpdate({
          on_call: e.target.value.split(',').map(email => email.trim())
        })}
        required
      />

      <motion.button
        type="submit"
        className="flex items-center gap-2 px-4 py-2 bg-blue-500/10 text-blue-400 rounded-lg hover:bg-blue-500/20 transition-colors"
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
      >
        Analyze Service
        <ChevronRight className="w-4 h-4" />
      </motion.button>
    </form>
  );
}