import React from 'react';
import { motion } from 'framer-motion';
import { ChevronRight } from 'lucide-react';
import { StepProps } from '../../../types/service';
import { Checkbox } from '../../ui/Checkbox';

export function ServiceDependencies({ data, onUpdate, onStepComplete }: StepProps) {
  const dependencies = [
    'PostgreSQL (RDS)',
    'Redis (Elasticache)',
    'MongoDB',
    'ElasticSearch'
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onStepComplete();
  };

  const handleDependencyChange = (dep: string, checked: boolean) => {
    const newDeps = checked
      ? [...data.dependencies, dep]
      : data.dependencies.filter(d => d !== dep);
    
    onUpdate({ dependencies: newDeps });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-2">
        <label className="block text-sm text-gray-400 mb-4">
          Select Service Dependencies
        </label>
        {dependencies.map((dep) => (
          <Checkbox
            key={dep}
            label={dep}
            checked={data.dependencies.includes(dep)}
            onCheckedChange={(checked) => handleDependencyChange(dep, checked)}
          />
        ))}
      </div>

      <motion.button
        type="submit"
        className="flex items-center gap-2 px-4 py-2 bg-green-500/10 text-green-400 rounded-lg hover:bg-green-500/20 transition-colors"
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
      >
        Next Step
        <ChevronRight className="w-4 h-4" />
      </motion.button>
    </form>
  );
}