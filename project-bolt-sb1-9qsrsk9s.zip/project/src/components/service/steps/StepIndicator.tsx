import React from 'react';
import { motion } from 'framer-motion';
import { Terminal } from 'lucide-react';

interface StepIndicatorProps {
  command: string;
  output?: string;
}

export function StepIndicator({ command, output }: StepIndicatorProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-1"
    >
      <div className="flex items-center gap-2 text-green-400">
        <Terminal className="w-4 h-4" />
        <span className="text-gray-500">$</span>
        <span>{command}</span>
      </div>
      {output && (
        <div className="pl-6 text-gray-400 border-l border-gray-700">
          {output}
        </div>
      )}
    </motion.div>
  );
}