import React from 'react';
import { motion } from 'framer-motion';
import { Checkbox } from '../../ui/Checkbox';
import { Input } from '../../ui/Input';
import { Button } from '../../ui/Button';
import { ServiceParameters } from '../../../types/service';

interface FinalStageProps {
  data: Pick<ServiceParameters, 'dependencies' | 'observability' | 'on_call'>;
  onUpdate: (data: Partial<ServiceParameters>) => void;
  onSubmit: () => void;
  onBack: () => void;
  loading?: boolean;
}

export function FinalStage({ data, onUpdate, onSubmit, onBack, loading }: FinalStageProps) {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit();
  };

  const handleDependencyToggle = (dependency: string, checked: boolean) => {
    const newDependencies = checked
      ? [...data.dependencies, dependency]
      : data.dependencies.filter(d => d !== dependency);
    onUpdate({ dependencies: newDependencies });
  };

  const handleOnCallChange = (value: string) => {
    onUpdate({
      on_call: value.split(',').map(email => email.trim()).filter(Boolean)
    });
  };

  return (
    <motion.form
      onSubmit={handleSubmit}
      className="space-y-6"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <div className="space-y-2">
        <label className="block text-sm text-gray-400">Dependencies</label>
        <div className="space-y-2">
          <Checkbox
            label="PostgreSQL (RDS)"
            checked={data.dependencies.includes('PostgreSQL (RDS)')}
            onCheckedChange={(checked) => handleDependencyToggle('PostgreSQL (RDS)', checked)}
          />
          <Checkbox
            label="Redis (Elasticache)"
            checked={data.dependencies.includes('Redis (Elasticache)')}
            onCheckedChange={(checked) => handleDependencyToggle('Redis (Elasticache)', checked)}
          />
        </div>
      </div>

      <Input
        label="Observability Logs"
        value={data.observability.logs}
        onChange={(e) => onUpdate({ 
          observability: { logs: e.target.value }
        })}
        placeholder="e.g., datadog"
        required
      />

      <Input
        label="On-Call Contacts"
        value={data.on_call.join(', ')}
        onChange={(e) => handleOnCallChange(e.target.value)}
        placeholder="Enter email addresses separated by commas"
        required
      />

      <div className="flex justify-between">
        <Button type="button" variant="ghost" direction="back" onClick={onBack}>
          Platform Config
        </Button>
        <Button type="submit" loading={loading}>
          Configure Service
        </Button>
      </div>
    </motion.form>
  );
}