import React from 'react';
import { motion } from 'framer-motion';
import { Input } from '../../ui/Input';
import { Button } from '../../ui/Button';
import { ServiceParameters } from '../../../types/service';

interface BasicInfoStageProps {
  data: Pick<ServiceParameters, 'name' | 'description'>;
  onUpdate: (data: Partial<ServiceParameters>) => void;
  onNext: () => void;
}

export function BasicInfoStage({ data, onUpdate, onNext }: BasicInfoStageProps) {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNext();
  };

  return (
    <motion.form
      onSubmit={handleSubmit}
      className="space-y-6"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <Input
        label="Service Name"
        value={data.name}
        onChange={(e) => onUpdate({ name: e.target.value })}
        placeholder="e.g., Upshot Backend Production"
        required
      />

      <Input
        label="Description"
        type="textarea"
        value={data.description}
        onChange={(e) => onUpdate({ description: e.target.value })}
        placeholder="Describe your service's primary function"
        required
      />

      <div className="flex justify-end">
        <Button type="submit" direction="next">
          Platform Configuration
        </Button>
      </div>
    </motion.form>
  );
}