import React from 'react';
import { motion } from 'framer-motion';
import { Input } from '../../ui/Input';
import { Select } from '../../ui/Select';
import { Button } from '../../ui/Button';
import { ServiceParameters } from '../../../types/service';

interface PlatformStageProps {
  data: Pick<ServiceParameters, 'platform'>;
  onUpdate: (data: Partial<ServiceParameters>) => void;
  onNext: () => void;
  onBack: () => void;
}

export function PlatformStage({ data, onUpdate, onNext, onBack }: PlatformStageProps) {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onNext();
  };

  const handlePlatformChange = (field: string, value: string) => {
    onUpdate({
      platform: { ...data.platform, [field]: value }
    });
  };

  return (
    <motion.form
      onSubmit={handleSubmit}
      className="space-y-6"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <Input
        label="Platform Name"
        value={data.platform.name}
        onChange={(e) => handlePlatformChange('name', e.target.value)}
        placeholder="e.g., ECS Fargate"
        required
      />

      <div className="grid grid-cols-2 gap-4">
        <Select
          label="Platform Type"
          value={data.platform.type}
          onChange={(e) => handlePlatformChange('type', e.target.value)}
          options={[
            { value: '', label: 'Select type' },
            { value: 'Compute', label: 'Compute' },
            { value: 'Storage', label: 'Storage' },
            { value: 'Network', label: 'Network' }
          ]}
          required
        />

        <Select
          label="Environment"
          value={data.platform.environment}
          onChange={(e) => handlePlatformChange('environment', e.target.value)}
          options={[
            { value: '', label: 'Select environment' },
            { value: 'development', label: 'Development' },
            { value: 'staging', label: 'Staging' },
            { value: 'production', label: 'Production' }
          ]}
          required
        />
      </div>

      <div className="flex justify-between">
        <Button type="button" variant="ghost" direction="back" onClick={onBack}>
          Basic Info
        </Button>
        <Button type="submit" direction="next">
          Dependencies & Contacts
        </Button>
      </div>
    </motion.form>
  );
}