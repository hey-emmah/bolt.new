import React from 'react';
import { ServiceForm } from './ServiceForm';
import { ContextBuilder } from './context/ContextBuilder';
import { useServiceAnalysis } from '../../hooks/useServiceAnalysis';
import { CommandHistory } from '../terminal/CommandHistory';

export function ServiceAnalyzer() {
  const { 
    loading, 
    error, 
    serviceResponse, 
    commands, 
    analyzeService, 
    addCommand 
  } = useServiceAnalysis();

  return (
    <div className="space-y-6">
      {commands.length > 0 && (
        <CommandHistory commands={commands} />
      )}

      {!serviceResponse ? (
        <ServiceForm 
          onSubmit={analyzeService}
          loading={loading}
        />
      ) : (
        <ContextBuilder 
          serviceResponse={serviceResponse}
          onCommand={addCommand}
        />
      )}
    </div>
  );
}