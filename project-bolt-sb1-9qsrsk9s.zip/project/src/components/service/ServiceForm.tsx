import React, { useState } from 'react';
import { ServiceParameters } from '../../types/service';
import { useServiceForm } from '../../hooks/useServiceForm';
import { BasicInfoStage } from './stages/BasicInfoStage';
import { PlatformStage } from './stages/PlatformStage';
import { FinalStage } from './stages/FinalStage';

interface ServiceFormProps {
  onSubmit: (params: ServiceParameters) => Promise<void>;
  loading?: boolean;
}

export function ServiceForm({ onSubmit, loading }: ServiceFormProps) {
  const [stage, setStage] = useState<'basic' | 'platform' | 'final'>('basic');
  const { formData, updateFormData } = useServiceForm();

  const handleSubmit = async () => {
    await onSubmit(formData);
  };

  return (
    <div className="space-y-6">
      {stage === 'basic' && (
        <BasicInfoStage
          data={formData}
          onUpdate={updateFormData}
          onNext={() => setStage('platform')}
        />
      )}

      {stage === 'platform' && (
        <PlatformStage
          data={formData}
          onUpdate={updateFormData}
          onNext={() => setStage('final')}
          onBack={() => setStage('basic')}
        />
      )}

      {stage === 'final' && (
        <FinalStage
          data={formData}
          onUpdate={updateFormData}
          onSubmit={handleSubmit}
          onBack={() => setStage('platform')}
          loading={loading}
        />
      )}
    </div>
  );
}