import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { AnalyzeResponse } from '../../types/service';
import { mockApi } from '../../lib/mockApi';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';

interface ContextBuilderProps {
  serviceResponse: AnalyzeResponse;
  onCommand: (command: string, output?: string) => void;
}

export function ContextBuilder({ serviceResponse, onCommand }: ContextBuilderProps) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<Record<string, string>>({});

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Convert parameter names to underscore format and build request body
      const requestBody = {
        context_id: serviceResponse.context_id,
        ...Object.fromEntries(
          Object.entries(formData).map(([key, value]) => [
            key.toLowerCase().replace(/\s+/g, '_'),
            value
          ])
        )
      };

      onCommand('build-context', 'Building context document...');
      const response = await mockApi.buildContext(requestBody);
      onCommand('context-build', 'Context document generated successfully');
      
      // Handle success (e.g., show document URL)
      console.log('Context URL:', response.cloudinary_url);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to build context';
      onCommand('context-build-failed', message);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (param: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [param]: value
    }));
  };

  return (
    <motion.form
      onSubmit={handleSubmit}
      className="space-y-6"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
    >
      {serviceResponse.required_parameters.map(param => (
        <Input
          key={param}
          label={param.split('.').join(' ').replace(/^\w/, c => c.toUpperCase())}
          value={formData[param] || ''}
          onChange={(e) => handleInputChange(param, e.target.value)}
          placeholder={`Enter ${param.split('.').join(' ')}`}
          required
        />
      ))}

      <Button
        type="submit"
        loading={loading}
        className="w-full"
      >
        Build Context
      </Button>
    </motion.form>
  );
}