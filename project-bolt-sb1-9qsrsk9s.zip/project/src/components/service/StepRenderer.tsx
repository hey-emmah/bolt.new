import React from 'react';
import { ServiceBasicInfo } from './steps/ServiceBasicInfo';
import { ServicePlatform } from './steps/ServicePlatform';
import { ServiceDependencies } from './steps/ServiceDependencies';
import { ServiceContacts } from './steps/ServiceContacts';
import { StepRendererProps } from '../../types/service';

export function StepRenderer({ 
  currentStep, 
  formData, 
  onStepComplete,
  onUpdate,
  onAnalyze 
}: StepRendererProps) {
  const steps = {
    basic: () => (
      <ServiceBasicInfo
        data={formData}
        onUpdate={onUpdate}
        onStepComplete={onStepComplete}
      />
    ),
    platform: () => (
      <ServicePlatform
        data={formData}
        onUpdate={onUpdate}
        onStepComplete={onStepComplete}
      />
    ),
    dependencies: () => (
      <ServiceDependencies
        data={formData}
        onUpdate={onUpdate}
        onStepComplete={onStepComplete}
      />
    ),
    contacts: () => (
      <ServiceContacts
        data={formData}
        onUpdate={onUpdate}
        onStepComplete={onStepComplete}
        onAnalyze={onAnalyze}
      />
    )
  };

  return steps[currentStep]?.() || null;
}