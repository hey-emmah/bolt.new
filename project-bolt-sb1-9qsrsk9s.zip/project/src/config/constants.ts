export const FORM_STEPS = [
  { id: 'basic', label: 'Basic Info', command: 'configure basic-info' },
  { id: 'platform', label: 'Platform', command: 'set platform-config' },
  { id: 'dependencies', label: 'Dependencies', command: 'add dependencies' },
  { id: 'contacts', label: 'Contacts', command: 'set on-call-contacts' },
] as const;

export const TERMINAL_THEME = {
  bg: '#1E1E1E',
  header: '#2D2D2D',
  border: '#2D2D2D',
  text: {
    primary: '#50FA7B',
    secondary: '#6B7280',
  }
} as const;