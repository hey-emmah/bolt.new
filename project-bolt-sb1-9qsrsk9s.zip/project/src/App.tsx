import React from 'react';
import { ServiceContextBuilder } from './components/ServiceContextBuilder';
import { TerminalWindow } from './components/layout/TerminalWindow';
import { AppHero } from './components/hero/AppHero';
import '@fontsource/fira-code';
import '@fontsource/inter';

export function App() {
  return (
    <div className="min-h-screen bg-[#1E1E1E] font-mono text-green-400">
      <TerminalWindow>
        <AppHero />
        <ServiceContextBuilder />
      </TerminalWindow>
    </div>
  );
}

export default App;