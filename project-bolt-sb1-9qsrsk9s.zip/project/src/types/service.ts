export interface ServiceParameters {
  name: string;
  description: string;
  platform: {
    name: string;
    type: string;
    environment: string;
  };
  dependencies: string[];
  observability: {
    logs: string;
  };
  on_call: string[];
}

export interface ServiceAnalysisResponse {
  service_name: 'valid' | 'invalid';
  platform_config: 'valid' | 'invalid';
  dependencies: 'valid' | 'invalid';
  contacts: 'valid' | 'invalid';
}

export interface AnalyzeResponse {
  required_parameters: string[];
  context_type: 'new' | 'existing';
  analysis: ServiceAnalysisResponse;
  context_id: string;
  vm_id: string;
}