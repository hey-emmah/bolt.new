export type ProvisioningStatusType = 'success' | 'in_progress' | 'failed';

export interface ProvisioningResponse {
  provisioningId: string;
}

export interface StatusResponse {
  status: ProvisioningStatusType;
  provisioningId: string;
}