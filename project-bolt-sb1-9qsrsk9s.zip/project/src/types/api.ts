export interface AnalyzeResponse {
  required_parameters: string[];
  context_type: 'new' | 'existing';
}